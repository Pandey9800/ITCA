<ul class="sidebar-menu">
<li class="header"><br/>Manage:</li>
<li class="active treeview">
<a href="dashboard" style="color:#fff;">
<i class="fa fa-dashboard"></i> <span>Home</span> </a></li>


<!-- <li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-male"></i>
<span>New Customers</span><i class="fa fa-angle-left pull-right"></i>
</a>
<ul class="treeview-menu">
<li><a href="newcustomer?self"><i class="fa fa-circle-o"></i>By Website</a></li>
<li><a href="newcustomer?staff"><i class="fa fa-circle-o"></i>By Staff </a></li>
</ul>
</li> -->

<li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-database"></i>
<span>Service Manage</span><i class="fa fa-angle-left pull-right"></i>
</a>
<ul class="treeview-menu">
<li><a href="category"><i class="fa fa-circle-o"></i>Category Manage</a></li>
<li><a href="service"><i class="fa fa-circle-o"></i>Service Manage</a></li>
<li><a href="documents-setup"><em class="fa fa-circle-o"></em>Documents Setup</a></li>
</ul>
</li>
<li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-files-o"></i>
<span>Applied Form</span><i class="fa fa-angle-left pull-right"></i>
<!--<span class="label label-primary pull-right">4</span>-->
</a>
<ul class="treeview-menu">
<li><a href="all-form"><i class="fa fa-circle-o"></i>New Form</a></li>
<li><a href="assign-task-list"><i class="fa fa-circle-o"></i>Assigned Form</a></li>
<li><a href="form-status"><i class="fa fa-circle-o"></i>Form Status</a></li>

</ul>
</li> 
<li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-users"></i>
<span>User Mangement</span><i class="fa fa-angle-left pull-right"></i>
</a>
<ul class="treeview-menu">
<li><a href="create-new-user"><i class="fa fa-circle-o"></i>User List</a></li>
<li><a href="create-new-user?add"><i class="fa fa-circle-o"></i>Add User</a></li>
</ul>
</li>
<!-- <li class="active treeview">
<a href="website-manage" style="color:#fff;">
<i class="fa fa-dashboard"></i> <span>Website Management</span> </a></li>   --> 
<li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-files-o"></i>
<span>Form List</span><i class="fa fa-angle-left pull-right"></i>
<!--<span class="label label-primary pull-right">4</span>-->
</a>
<ul class="treeview-menu">
<?php
$formsql=mysqli_query($con,"SELECT `id`,`name` FROM `service` ORDER BY `name` ASC");
while($rows=mysqli_fetch_array($formsql)){?>
<li><a href="form?id=<?php echo $rows['id']; ?>"><em class="fa fa-circle-o"></em><?php echo ucwords($rows['name']); ?></a></li>
<?php }?>
</ul>
</li>   
<li class="treeview">
<a href="" style="color:#fff;">
<i class="fa fa-files-o"></i>
<span>Coupon Manage</span><i class="fa fa-angle-left pull-right"></i>
<!--<span class="label label-primary pull-right">4</span>-->
</a>
<ul class="treeview-menu">
<li><a href="view-coupan"><em class="fa fa-circle-o"></em>Coupon Manage</li>
<li><a href="coupan-transfer"><em class="fa fa-circle-o"></em>Coupon Transfer</li>
<li><a href="coupan-report"><em class="fa fa-circle-o"></em>Coupon Report</li>
</ul>
</li>   
</ul>